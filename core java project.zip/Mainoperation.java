/***************************CORE JAVA PROJECT**********************************
* 
*                     CSR CAPGEMINI TRAINING PROGRAM
*                     
*                     EDUBRIDGE INDIA PRIVATE LIMITED
*                     
*                  PROJECT TITLE: STUDENT MANAGEMENT SYSTEM
*                  
*               UNDER THE GUIDENCE OF TRAINER MRS.INDRAKKA BASAPPA MALI 
*               
*                                                     @DONE BY SNEHA P
*In student management system,
*The 5 operations are:
*1.Add student   
*2.Search the student
*3.Update the student
*4.Delete the student
*5.Display student detail
                                                
*/
package stu.in;
import java.util.Scanner;
public class Mainoperation {
	static Studentservice service = new Studentservice();
	static boolean ordering = true;
	public static void menu() {
		System.out.println("*******************WELCOME TO STUDENT MANAGEMENT SYSTEM*******************"
	   +"\n1.Add Student"
	   +"\n2.Search Student"
	   +"\n3.Update Student"
	   +"\n4.Delete Student"
	   +"\n5.Display Student Detail"
	   +"\n6.Exit");
		
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		do {
			menu();
			System.out.println("Enter the choice:");
			int choice = sc.nextInt();
			switch(choice) {
			case 1:
				System.out.println("Add Student");
				service.addstudent();
				break;
			case 2:
				System.out.println("Search Student");
				service.searchstudent();
				break;
			case 3:
				System.out.println("Update Student");
				service.updatestudent();
				break;
			case 4:
				System.out.println("Delete Student");
				service.deletestudent();
				break;
			case 5:
				System.out.println("Display Students Detail");
				service.displaystudent();
				break;
			case 6:
				System.out.println("Thank you for using application!!");
				System.exit(0);
			
			default:
				System.out.println("Please enter valid choice");
				
			}
			
		    }while(ordering);
	}

}
