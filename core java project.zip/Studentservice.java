package stu.in;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
public class Studentservice {
	HashSet<Student> stuset = new HashSet<Student>();
	Student st1 = new Student(1001,"Sneha",34,"comp","sneha@gmail.com","6037896534");
	Student st2 = new Student(1002,"Abinaya",35,"IT","abinaya@gmail.com","6837896534");
	
	
	Scanner sc=new Scanner(System.in);
	boolean found=false;
	int id;
	String name;
	int deptcode;
	String department;
	String gmail;
	String phno;
	public Studentservice() {
		
		stuset.add(st1);
		stuset.add(st2);
}
	//add student
		public void addstudent() {
			System.out.println("Enter id:");
			id=sc.nextInt();
			System.out.println("Enter name:");
			name=sc.next();
			System.out.println("Enter deptcode:");
			deptcode=sc.nextInt();
			System.out.println("Enter department:");
			department=sc.next();
			System.out.println("Enter gmail:");
			gmail=sc.next();
			System.out.println("Enter phno:");
			phno=sc.next();
			
			Student st=new Student(id, name, deptcode, department, gmail, phno);
			
			stuset.add(st);
			System.out.println(st);
			System.out.println("Student added successfully");
			
		}
		//search student
		public void searchstudent(){
			
			System.out.println("Enter id: ");
			id=sc.nextInt();
			for(Student st:stuset) {
				if(st.getId()==id) {
					System.out.println(st);
					found=true;
				}
				
			}
			if(!found) {
				System.out.println("Student with this id is not present");
			}
		}
		//update the student
		public void updatestudent() {
			System.out.println("Enter id: ");
			id=sc.nextInt();
			boolean found=false;
			for(Student st:stuset) {
				if(st.getId()==id) {
					System.out.println("Enter new name: ");
					name=sc.next();
					System.out.println("Enter new phno");
					phno=sc.next();
					st.setName(name);
					st.setphno(phno);
					System.out.println("Updated Details of student are: ");
					System.out.println(st);
					found=true;
				}
			}
			if(!found) {
				System.out.println("Student is not present");
			}
			else {
				System.out.println("Student details updated successfully !!");
			}
		}
		//delete student
		public void deletestudent() {
			System.out.println("Enter id");
			id=sc.nextInt();
			boolean found=false;
			Student stdelete=null;
			for(Student st:stuset) {
				if(st.getId()==id) {
					stdelete=st;
					found=true;
				}
			}
			if(!found) {
				System.out.println("Student is not present");
			}
			else {
				stuset.remove(stdelete);
				System.out.println("Student deleted successfully!!");
			}
		}
	//display students
		public void displaystudent() {
			/*for(Student st:stuset) {
				System.out.println(st);
			}
		}*/
			/*if(stuset.isEmpty()) {
				System.out.println("There is no record");
			}
			for(Student st:stuset) {
				System.out.println(st.toString());
			}*/

	        Iterator<Student> it=stuset.iterator();
	        System.out.println("ID\t  Name\t\tDeptcode\tDepartment\tGmail\t\t\tPhno");
	        System.out.println("-------------------------------------------------------------------------------------------------------------");
	        
	        while(it.hasNext()) {
	        	Student sob=it.next();
	        	//System.out.println(sob.getId()+"\t"+sob.getName()+"\t"+sob.getFees());
	        	System.out.printf("%d",sob.getId());
	        	System.out.printf("%15s",sob.getName());
	        	System.out.printf("\t%d",sob.getdeptcode());
	        	System.out.printf("\t%15s",sob.getDepartment());
	        	System.out.printf("\t\t%15s",sob.getgmail());
	        	System.out.printf("\t\t%15s",sob.getphno());
	        	System.out.printf("\n");//System.out.println();
	        	
	        }
		
		}
}
